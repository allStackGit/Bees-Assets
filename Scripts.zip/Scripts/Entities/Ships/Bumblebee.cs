﻿
using UnityEngine;

namespace Assets.Scripts.Entities.Ships
{
    public class Bumblebee : Ship
    {
        
    }
}